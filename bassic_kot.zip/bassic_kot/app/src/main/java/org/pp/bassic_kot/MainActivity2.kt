package org.pp.bassic_kot

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        val button3 = findViewById<Button>(R.id.button3)
        button3.setOnClickListener {
            finish()
        }

        var name : String = ""

        val thirdIntent = Intent(this, MainActivity3::class.java)
        val Intent4 = Intent(this, MainActivity4::class.java)

        val modcols_more = findViewById<Button>(R.id.modcols_more)
        modcols_more.setOnClickListener {
            name = getString(R.string.ModcolS_name)
            startActivity(thirdIntent)
        }

        val taksen_more = findViewById<Button>(R.id.taksen_more)
        taksen_more.setOnClickListener {
            name = getString(R.string.Taksen_name)
            startActivity(Intent4)
        }


    }
}